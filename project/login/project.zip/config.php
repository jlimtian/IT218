<?php
	$host="sql1.njit.edu";
	$database="jag94";
	$username="jag94";
	$password="hallow98";
?>