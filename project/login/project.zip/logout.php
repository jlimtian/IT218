<!DOCTYPE html>
<html lang="em">

<head>
    <!-- meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1,
        shrink-to-fit=no">
    <!-- main.css -->
    <link rel="stylesheet" href="logout.css">
    <!-- Favicon and Tab Head -->
    <title>Logout | Just Do It</title>
</head>
<body>
    <header>
            <div class="header" id="myHeader">
            <h1>Just Do It</h1>
        </div>
    </header>
    <main>
	<img src="background.jpg" alt="Background">
        <form>
		<h3>You have been logged out.</h3><br><br>
        </form>
    </main>
</body>
<footer>
        <div class="footer" id="myFooter">
                <span class="text-muted">&copy; Jhanelle Gray and Juline Limtian, 2019 |
                    Terms Of Use  |  Privacy Statement </span>
        </div>
</footer>
</html>