--
-- Database: `jag94`
--

-- --------------------------------------------------------

--
-- Table structure for table `accounts`
--
USE `jag94`;-- put your database name in the single quotes

DROP TABLE IF EXISTS `accounts`;

CREATE TABLE  `accounts` (
`id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `fname` varchar(30) DEFAULT NULL,
  `lname` varchar(30) DEFAULT NULL,
  `college` varchar(20) DEFAULT NULL,
  `major` varchar(30) DEFAULT NULL,
  `email` varchar(60) DEFAULT NULL,
  `password` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `accounts`
--

INSERT INTO `accounts` (`id`, `fname`, `lname`, `college`, `major`, `email`, `password`) VALUES
(1, 'Mike', 'Lee', 'NJIT', 'Engineering', 'mjlee@njit.edu', '1234'),
(2, 'John', 'Doe', 'Rutgers', 'Dance', 'janedoe@njit.edu', '1234'),
(3, NULL, NULL, NULL, NULL,  'ml4q73@njit.edu', '1'),
(4, '1', '1', 'MSU', 'Theatre', 'ml24q73@njit.edu', '2'),
(5, '1', '1', 'MSU', 'Theatre', 'ml241q73@njit.edu', '1'),
(6, '', '', '', 'NYCU', 'js829', '123'),
(7, 'yong', 'zhao', 'Caldwell', 'Robotics', 'test@njit.edu', '1234'),
(8, 'Rebecca', 'cortes', 'Rutgers', 'Psychology', 'Rebecca@gmail.com', 'cortes'),
(9, 'jay', '', '', '', '', ''),
(10, 'test', 'test', 'NJIT', 'Architecture', 'test@gmail.com', 'test'),
(11, 'test', 'test', 'NJIT', 'Architecture', 'test2@gmail.com', 'test'),
(12, 'yong', 'yong', 'Rutgers', 'Drama', 'mjlee@njit.edu0', '1234');

-- --------------------------------------------------------

--
-- Table structure for table `todos`
--
DROP TABLE IF EXISTS `todos`;

CREATE TABLE `todos` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `owneremail` varchar(60) DEFAULT NULL,
  `ownerid` int(11) DEFAULT NULL,
  `title` text,
  `createddate` datetime DEFAULT NULL,
  `duedate` datetime DEFAULT NULL,
  `message` text,
  `isdone` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `todos`
--

INSERT INTO `todos` (`id`, `owneremail`, `ownerid`, `title`, `createddate`, `duedate`, `message`, `isdone`) VALUES
(1, 'janedoe@njit.edu', 2, 'test2', '2017-01-01 00:00:00', '2017-05-03 00:00:00', 'This is test #B', 0),
(2, 'mjlee@njit.edu', 1, 'new2', '2017-05-03 00:00:00', '2017-05-27 00:00:00', 'new name 2', 0),
(3, 'janedoe@njit.edu', 2, 'test1', '2017-01-01 00:00:00', '2017-05-01 00:00:00', 'This is test #A', 0),
(4, 'mjlee@njit.edu', 1, 'test', '2017-05-03 00:00:00', '2017-05-26 00:00:00', 'test again', 0),
(5, 'mjlee@njit.edu', 1, '111', '2017-05-07 00:00:00', '2017-05-28 00:00:00', '1111', 0),
(6, 'test@gmail.com', 10, 'hello', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 'HELLO', 0);


