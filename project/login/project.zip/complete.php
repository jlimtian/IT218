<?php
	require 'db.php';
	
	if (isset($_POST['btncomp'])) {
		$sql = "UPDATE todos SET isdone = 1 WHERE id = :idVal";
		$idVal = $_POST['btncomp'];
	}
	
	if (isset($_POST['btninco'])) {
		$sql = "UPDATE todos SET isdone = 0 WHERE id = :idVal";
		$idVal = $_POST['btninco'];
	}
	
	
	$db = new connection_db();
	$conn = $db->connectDB();
	$run_q = new run_SQL();
	$results = $run_q->runDeleteQuery($sql, $conn, $idVal);
	
	header("refresh: 0, url='show.php'");
	exit();
?>